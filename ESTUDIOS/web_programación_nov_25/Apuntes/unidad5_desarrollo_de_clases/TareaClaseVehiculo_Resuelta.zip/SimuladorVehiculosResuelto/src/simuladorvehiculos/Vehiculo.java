/*
 * Clase Vehiculo.
 */
package simuladorvehiculos;

/**
 * Clase que representa un <strong>vehículo</strong>.
 * <p>
 * Los objetos de esta clase contienen atributos que que permiten almacenar
 * información sobre:</p>
 * <ul>
 * <li><strong>Capacidad del depósito</strong> de combustible (litros).</li>
 * <li><strong>Consumo medio</strong> del vehículo (litros/100km).</li>
 * <li><strong>Estado del motor</strong> (<strong>encendido</strong> o <strong>apagado</strong>).</li>
 * <li><strong>Nivel de combustible</strong> actual (litros).</li>
 * <li><strong>Distancia recorrida</strong> desde que se arrancó el motor por última vez (y no se
 * ha apagado) (km).</li>
 * <li><strong>Distancia recorrida total</strong> desde que el objeto se creó (km).</li>
 * <li><strong>Combustible consumido</strong> desde que se arrancó el motor por última vez (y no
 * se ha apagado) (litros).</li>
 * <li><strong>Combustible total consumido</strong> desde que el objeto se creó (litros).</li>
 * </ul>
 * <p>
 * La clase también dispone de información general independiente de los objetos
 * concretos que se hayan creado. Es el caso de:</p>
 * <ul>
 * <li><strong>Distancia recorrida total</strong> por <strong>todos los vehículos</strong> que se hayan creado
 * hasta el momento (km).</li>
 * <li><strong>Combustible total consumido</strong> por <strong>todos los vehículos</strong> que se hayan creado
 * hasta el momento (litros).</li>
 * <li><strong>Número de vehículos</strong> con el <strong>motor encendido</strong> en el momento actual.</li>
 * </ul>
 *
 * @author Profesor
 */
public class Vehiculo {

    // ATRIBUTOS ESTÁTICOS (de clase)
    // ------------------------------
    // Atributos estáticos constantes
    private static final double MIN_CONSUMO_MEDIO = 2.00;   // litros/100km 
    private static final double MAX_CONSUMO_MEDIO = 20.00;   // litros/100km 
    private static final double MIN_CAPACIDAD_DEPOSITO = 10.00;   // litros
    private static final double MAX_CAPACIDAD_DEPOSITO = 120.00;   // litros
    private static final double CONSUMO_COMBUSTIBLE_ARRANQUE = 0.02;   // litros

    private static final double CONSUMO_MEDIO_DEFAULT = 5.00;   // litros/100km
    private static final double CAPACIDAD_DEPOSITO_DEFAULT = 50.00;   // litros 

    // Atributos estáticos 
    private static double distanciaRecorridaFlota;        // Distancia recorrida total por todos los vehículos de la flota (en km)
    private static double combustibleConsumidoFlota;      // Combustible consumido total por todos los vehículos de la flota (en litros)
    private static long numVehiculosArrancadosFlota;    // Número de vehículos activos (arrancados) en la flota  

    // ATRIBUTOS DE OBJETO
    // -------------------
    // Atributos constantes durante la vida del vehículo (desde que se crea el objeto)
    // Podrían también haberse declarado como constantes y habría sido válido
    private double consumoMedio;        // Consumo medio del vehículo (litros/100km)
    private double capacidadDeposito;   // Capacidad del depósito de combustible del vehíclo

    // Atributos variables
    private boolean encendido;                  // Estado del motor: encendido (true) o apagado (false)
    private double nivelCombustible;           // Nivel de combustible actual del vehículo (litros)

    private double distanciaRecorrida;          // Distancia recorrida por el vehículo desde que se arrancó hasta el instante actual (km)
    private double combustibleConsumido;        // Combustible consumido por el vehículo desde que se arrancó hasta el instante actual (litros)

    private double distanciaRecorridaTotal;     // Distancia total recorrida por el vehículo desde que se fabricó hasta el momento actual (km)
    private double combustibleConsumidoTotal;   // Combustible total consumido por el vehículo desde que se fabricó hasta el momento actual (km)

    // CONSTRUCTORES
    // -------------
    /**
     * Constructor por defecto de la clase. Crea un objeto Vehiculo con un
     * consumo medio de 5.0 litros/100km y un depósito de una capacidad de 50.0 litros.
     */
    public Vehiculo() {
        this(Vehiculo.CONSUMO_MEDIO_DEFAULT, Vehiculo.CAPACIDAD_DEPOSITO_DEFAULT);
    }

    /**
     * Constructor con parámetros.
     *
     * @param consumoMedio Consumo medio del vehículo (l/100km). Debe estar entre 2.0 y 20.0.
     * @param capacidadDeposito Capacidad del depósito del vehículo (litros). Debe estar entre 10.0 y 120.0
     * @throws IllegalArgumentException Si alguno de los parámetros está fuera del rango permitido.
     */
    public Vehiculo(double consumoMedio, double capacidadDeposito) throws IllegalArgumentException {

        // Comprobación de que los parámetros son válidos
        if (consumoMedio < Vehiculo.MIN_CONSUMO_MEDIO || consumoMedio > Vehiculo.MAX_CONSUMO_MEDIO
                || capacidadDeposito < Vehiculo.MIN_CAPACIDAD_DEPOSITO || capacidadDeposito > Vehiculo.MAX_CAPACIDAD_DEPOSITO) {
            // Alguno de los parámetros de construcción no es válido
            // No se crea un objeto Vehiculo.
            // Se lanza una excepción.
            throw new IllegalArgumentException("Error: Parámetros de creación del vehículo inválidos.");
        } else {
            // Los valores de los parámetros son válidos
            this.consumoMedio = consumoMedio;
            this.capacidadDeposito = capacidadDeposito;

            // Inicialización de atributos que no van a dar problemas
            this.encendido = false;              // Motor apagado
            this.nivelCombustible = 0;           // Vacío de combustible
            this.distanciaRecorrida = 0;         // Sin distancias recorridas
            this.distanciaRecorridaTotal = 0;
            this.combustibleConsumido = 0;       // Sin consumos
            this.combustibleConsumidoTotal = 0;
        }
    }

    // MÉTODOS CONSULTORES (o "getters")
    // ---------------------------------
    /**
     * 
     * @return Si el motor del vehículo está arrancado o no.
     */
    public boolean isArrancado() {
        return this.encendido;
    }    
    
    /**
     * 
     * @return El consumo medio del vehículo (en litros/100km).
     */ 
    public double getConsumoMedio() {
        return consumoMedio;
    }
    
    /**
     * 
     * @return La capacidad del depósito de combustible del vehículo (en litros).
     */
    public double getCapacidadDeposito() {
        return capacidadDeposito;
    }

    /**
     * 
     * @return El nivel actual del depósito de combustible del vehículo (en litros).
     */
    public double getNivelCombustible() {
        return nivelCombustible;
    }
    
    /**
     * 
     * @return La distancia recorrida por el vehículo desde que ha sido arrancado por última vez (en km).
     * El vehículo debe estar arrancado. Si no, los contadores se habrán puesto a cero.
     */
    public double getDistanciaRecorrida() {
        return distanciaRecorrida;
    }
    
    /**
     * 
     * @return La distancia total recorrida por el vehículo desde su fabricación.
     */
    public double getDistanciaRecorridaTotal() {
        return distanciaRecorridaTotal;
    }   

    /**
     * 
     * @return El combustible que ha sido consumido por el vehículo desde que ha sido arrancado por última vez (en litros).
     * El vehículo debe estar arrancado. Si no, los contadores se habrán puesto a cero.
     */
    public double getCombustibleConsumido() {
        return combustibleConsumido;
    }
    
    /**
     * 
     * @return El combustible total que ha sido consumido por el vehículo desde su fabricación (en litros).
     */
    public double getCombustibleConsumidoTotal() {
        return combustibleConsumidoTotal;
    }

    /**
     * 
     * @return La distancia recorrida total por todos los vehículos que se hayan creado hasta el momento (en km).
     */
    public static double getDistanciaRecorridaFlota() {
        return distanciaRecorridaFlota;
    }
    
    /**
     * 
     * @return El combustible total que ha sido consumido por todos los vehículos que hayan sido creados hasta el momento (en litros).
     */    
    public static double getCombustibleConsumidoFlota() {
        return combustibleConsumidoFlota;
    }

    /**
     * 
     * @return El número de vehículos que haya con el motor encendido en ese momento.
     */
    public static long getNumVehiculosArrancadosFlota() {
        return numVehiculosArrancadosFlota;
    }

    // MÉTODOS DE ACCIÓN
    // -----------------  
    /**
     * Rellena el depósito de combustible del vehículo con una cantidad de litros.
     * Recibirá un parámetro que indicará la cantidad de litros para repostar.
     * Se actualizará el nivel de combustible del vehículo en función del valor del parámetro que se le pase.
     * Ahora bien, podrían darse algunos casos de error lanzarán una excepción.
     * @param litros Cantidad de litros para repostar.
     * @throws IllegalStateException Si el motor está arrancado.
     * @throws IllegalArgumentException Si la cantidad de combustible que se intenta repostar es superior a la que puede admitir el depósito en ese momento.
     * El depósito se llenará completamente pero se producirá un rebosamiento.
     */
    public void repostar(double litros) throws IllegalStateException, IllegalArgumentException {
        double repostajeReal;

        if (this.encendido) {
            // Si el motor está encendido no se puede repostar
            // Lanzamos excepción
            throw new IllegalStateException("Error: Se intentó repostar con el motor encendido. No se ha repostado.");
        } else {

            if (litros <= this.capacidadDeposito - this.nivelCombustible) {
                // La cantidad que se desea repostar cabe en el depósito
                repostajeReal = litros;
                this.nivelCombustible += repostajeReal;
            } else {
                // La cantidad que se desea repostar no cabe en el depósito
                repostajeReal = this.capacidadDeposito - this.nivelCombustible;
                // Rellenamos hasta donde quepa
                this.nivelCombustible += repostajeReal;
                // Lanzamos excepción
                throw new IllegalArgumentException("Error: Depósito lleno. Se ha desbordado el combustible en " + (litros - repostajeReal) + " litros.");
            }
        }
    }
    
    /**
     * Arranca el motor del vehículo.
     * Esta acción hará que se produzca un pequeño consumo de combustible de 0.02 litros.
     * @throws IllegalStateException Si el motor está ya encendido o si en el depósito no hay suficiente combustible para arrancar.
     */
    public void arrancar() throws IllegalStateException {
        if (!this.encendido) {
            if (nivelCombustible < Vehiculo.CONSUMO_COMBUSTIBLE_ARRANQUE) {
                // El vehículo no puede arrancar por no tener combustible suficiente
                this.nivelCombustible = 0; // Gastamos lo que pudiera quedar
                // Lanzamos excepción
                throw new IllegalStateException("Error: Depósito vacío. Se intentó arrancar sin combustible suficiente.");
            }
            // Hay combustible suficiente para arrancar
            this.encendido = true;
            actualizarNivelCombustible(Vehiculo.CONSUMO_COMBUSTIBLE_ARRANQUE);
            Vehiculo.numVehiculosArrancadosFlota++;
        } else {
            // El motor ya estaba arrancado. Lanzamos excepción
            throw new IllegalStateException("Error: El motor ya se encuentra arrancado.");
        }

    }

    /**
     * Hace que el vehículo realice un trayecto de una determinada cantidad de kilómetros que se pasarán como parámetro.
     * @param distancia Distancia en km que se desea recorrer.
     * @throws IllegalStateException Si está el motor apagado. Para poder realizar un trayecto
     * el motor del vehículo debe estar arrancado.
     * @throws IllegalArgumentException Si no hay combustible suficiente para recorrer esa distancia.
     * En tal caso se consume todo el depósito, se recorre la distancia que sea posible, y se apaga el motor.
     * También se puede producir esta excepción si la distancia proporcionada es negativa.
     */
    public void realizarTrayecto(double distancia) throws IllegalStateException, IllegalArgumentException {
        if (!this.encendido) {
            // Si el motor está apagado no se recorrer ningún trayecto
            // Lanzamos excepción
            throw new IllegalStateException("Error: Se intentó realizar un trayecto con el motor apagado. No se ha avanzado.");
        } else if (distancia < 0) {
            // Si el parámetro distancia es negativo, es un error
            // Lanzamos excepción
            throw new IllegalArgumentException("Error: Se intentó realizar un trayecto negativo.");

        }

        double distanciaRecorridaReal;
        double consumoReal;

        // Cálculo del consumo que sería necesario
        double consumoCalculado = distancia * this.consumoMedio / 100.0;
        if (consumoCalculado <= this.nivelCombustible) {
            // Se puede realizar el trayecto completo pues hay combustible suficiente
            recorrerDistancia(distancia);  // Recorremos esa distancia
            actualizarNivelCombustible(consumoCalculado);  // Consumimos el combustible necesario
        } else {  // No hay suficiente combustible en el depósito para realizar el trayecto
            // Calculamos la distancia que va a ser posible recorrer
            consumoReal = this.nivelCombustible;
            distanciaRecorridaReal = consumoReal / (this.consumoMedio / 100.0);
            // Recorremos la distancia que se pueda
            recorrerDistancia(distanciaRecorridaReal);
            // Consumimos todo el combustible
            actualizarNivelCombustible(consumoReal);
            // Apagamos el motor
            this.apagar();
            // Lanzamos una excepción
            throw new IllegalArgumentException("Error: No se ha podido finalizar el trayecto completamente. Depósito vacío. Han faltado por recorrer "
                    + String.format("%5.2f", (distancia - distanciaRecorridaReal)) + " km.");
        }

    }

    /**
     * Apaga el motor del vehículo y reinicia a cero los indicadores de consumo y distancia recorrida desde el último arranque.
     * @throws IllegalStateException Si el motor ya está apagado.
     */
    public void apagar() throws IllegalStateException {
        if (this.encendido) {
            // Reseteamos los contadores y apagamos el motor
            this.combustibleConsumido = 0;
            this.distanciaRecorrida = 0;
            this.encendido = false;
            Vehiculo.numVehiculosArrancadosFlota--;
        } else {
            // Si el motor ya está apagado, no se puede apagar. Lanzamos excepción
            throw new IllegalStateException("Error: El motor ya se encuentra apagado.");
        }
    }

    /**
     *
     * @return <p>Cadena que representa el estado actual del vehículo proporcionando la siguiente información:</p>
     * <ol>
     * <li><strong>Estado del motor</strong> (<strong>encendido</strong> o <strong>apagado</strong>).</li>
     * <li><strong>Nivel del depósito de combustible</strong>.</li>
     * <li><strong>Distancia recorrida</strong> desde que se ha arrancado (si es que el motor está arrancado, pues si está apagado será obviamente cero).</li>
     * <li><strong>Consumo realizado</strong> desde que se ha arrancado (si es que el motor está arrancado, pues si está apagado será obviamente cero).</li>
     * </ol>
     * <p><strong>El formato de salida</strong> será del siguiente tipo: </p>
     * <pre>Motor: XXX - Deposito: YYY - Dist: ZZZ - Consumo: VVV</pre>
     * <p>donde XXX podrá ser encendido o apagado; YYY será el nivel del depósito expresado en litros y con dos decimales; 
     * ZZZ será la distancia recorrida expresada en kilómetros y con dos decimales, 
     * y VVV el consumo expresado en litros y con dos decimales.</p>
     * <p> Algunos ejemplos de este <code>String</code> de salida podrían ser:</p>
     * <ul>
     * <li><pre>Motor: apagado   - Depósito:   0,00 - Dist:     0,00 - Consumo:     0,00</pre></li>
     * <li><pre>Motor: arrancado - Depósito:   4,98 - Dist:     0,00 - Consumo:     0,02</pre></li>
     * <li><pre>Motor: arrancado - Depósito:   4,23 - Dist:    15,00 - Consumo:     0,77</pre></li>
     * <li><pre>Motor: apagado   - Depósito:   4,23 - Dist:     0,00 - Consumo:     0,00</pre></li>
     * <li><pre>Motor: arrancado - Depósito:   4,68 - Dist:    10,00 - Consumo:     0,32</pre></li>
     * </ul>
     */
    @Override
    public String toString() {
        // La cadena se irá construyendo sobre un objeto StringBuilder
        // StringBuilder es más eficiente que el uso de Strings
        String sep1 = " - ";
        StringBuilder resultado = new StringBuilder();

        // Fila cabecera con las coordenadas de columna
        //resultado.append("   ");
        String estado = this.encendido ? "arrancado" : "apagado";
        resultado.append("Motor: ");
        resultado.append(String.format("%-9s", estado));
        resultado.append(sep1);

        resultado.append("Depósito: ");
        resultado.append(String.format("%6.2f", this.nivelCombustible));
        resultado.append(sep1);

        resultado.append("Dist: ");
        resultado.append(String.format("%8.2f", this.distanciaRecorrida));
        resultado.append(sep1);

        resultado.append("Consumo: ");
        resultado.append(String.format("%8.2f", this.combustibleConsumido));

        // Devolvemos la cadena construida*/
        return resultado.toString();
    }

    // ------------------  
    // MÉTODOS "PRIVADOS"
    // ------------------  
    /**
     * Método utilizado para llevar a cabo todas las acciones necesarias para
     * actualizar el nivel de combustible del depósito. Se encarga de actualizar
     * todos los atributos que sean necesarios y de la manera apropiada.
     * Como es posible que haya que hacerlo varias veces (en distintos métodos),
     * se ha escrito una sola vez y encapsulado en un método que será llamado
     * cuando sea necesario
     * @param cantidad Cantidad en litros para actualizar el nivel de combustible
     */
    private void actualizarNivelCombustible(double cantidad) {
        double cantidadConsumidaReal;
        if (cantidad <= this.nivelCombustible) {
            cantidadConsumidaReal = cantidad;
        } else {
            cantidadConsumidaReal = this.nivelCombustible;
        }

        this.nivelCombustible -= cantidadConsumidaReal;
        this.combustibleConsumido += cantidadConsumidaReal;
        this.combustibleConsumidoTotal += cantidadConsumidaReal;
        Vehiculo.combustibleConsumidoFlota += cantidadConsumidaReal;
    }
    
    /**
     * Método utilizado para llevar a cabo todas las acciones necesarias para
     * recorrer una determinada distancia. Se encarga de actualizar
     * todos los atributos que sean necesarios y de la manera apropiada.
     * Como es posible que haya que hacerlo varias veces (en distintos métodos),
     * se ha escrito una sola vez y encapsulado en un método que será llamado
     * cuando sea necesario     
     * @param distancia Distancia en km que se va a recorrer.
     */
    private void recorrerDistancia(double distancia) {
        this.distanciaRecorrida += distancia;
        this.distanciaRecorridaTotal += distancia;
        Vehiculo.distanciaRecorridaFlota += distancia;
    }

    
}
