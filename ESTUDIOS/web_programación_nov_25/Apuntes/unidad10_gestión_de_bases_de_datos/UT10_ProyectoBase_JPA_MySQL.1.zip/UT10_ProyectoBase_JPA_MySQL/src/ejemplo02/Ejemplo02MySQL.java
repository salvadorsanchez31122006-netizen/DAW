package ejemplo02;

import java.util.HashMap;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

public class Ejemplo02MySQL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Map<String,String> propiedades=new HashMap<>();
            /* driver utilizado en esta conexi�n */
            propiedades.put("javax.persistence.jdbc.driver", "com.mysql.cj.jdbc.Driver");
            /* URL para conectar a la base de datos*/
            propiedades.put("javax.persistence.jdbc.url", "jdbc:mysql://localhost:3306/ut10?serverTimezone=UTC");
            /* nombre de usuario para conectar */
            propiedades.put("javax.persistence.jdbc.user", "ut10");
            /* password para necesario para conectar */
            propiedades.put("javax.persistence.jdbc.password", "ut10");                      
            /* modelo de generaci�n de base de datos */
            propiedades.put("javax.persistence.schema-generation.database.action", "create");             
                         
            EntityManagerFactory emf=Persistence.createEntityManagerFactory("EjemplosJPA",propiedades);
            EntityManager em=emf.createEntityManager();
            
            if (em.isOpen())
            {
                System.out.println("EntityManager con conexi�n abierta.");
            }
            else
            {
                System.out.println("EntityManager sin conexi�n.");
            }
            
            em.close();
            emf.close();
        } catch (PersistenceException pe) {
            System.err.println("Error al conectar con la base de datos.");
        }
    }
    
}
