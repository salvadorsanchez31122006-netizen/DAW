package ejemplopolimorfismoinstrumentos;

/**
 * Clase que representa a una flauta
 */
public class Flauta extends Instrumento {

    /**
     * Toca una nota musical con la flauta.
     * @param nota Nota musical que se va a tocar.
     * @return String que representa que se ha tocado
     * una determinada nota con la flauta.
     */
    @Override
    public String tocarNota (String nota) {
        return ("Flauta: tocar nota " + nota);
    }    

}