package ejemplopolimorfismoinstrumentos;

/**
 * Clase que representa a un piano
 */
public class Piano extends Instrumento {

    /**
     * Toca una nota musical con el piano.
     * @param nota Nota musical que se va a tocar.
     * @return String que representa que se ha tocado
     * una determinada nota con el piano.
     */
    @Override
    public String tocarNota (String nota) {
        return ("Piano: tocar nota " + nota);
    }    

}
