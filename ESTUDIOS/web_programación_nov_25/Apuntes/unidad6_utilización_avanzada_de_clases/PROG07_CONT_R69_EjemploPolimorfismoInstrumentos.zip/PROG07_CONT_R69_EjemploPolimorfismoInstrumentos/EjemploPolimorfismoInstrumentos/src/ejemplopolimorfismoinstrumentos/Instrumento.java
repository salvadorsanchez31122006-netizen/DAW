package ejemplopolimorfismoinstrumentos;

/**
 * Clase que representa a un instrumento musical
 */
public abstract class Instrumento {

    /**
     * Toca una nota musical con el instrumento.
     * @param nota Nota musical que se va a tocar.
     * @return String que representa que se ha tocado
     * una determinada nota con el instrumento.
     */
    public String tocarNota (String nota) {
        return ("Instrumento: tocar nota " + nota);
    }  

}
