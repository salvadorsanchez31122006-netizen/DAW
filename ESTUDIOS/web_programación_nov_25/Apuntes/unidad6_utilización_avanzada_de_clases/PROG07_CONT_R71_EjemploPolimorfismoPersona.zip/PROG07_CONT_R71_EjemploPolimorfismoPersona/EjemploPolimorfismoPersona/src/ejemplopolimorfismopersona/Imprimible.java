/*
 * Interfaz Imprimible
 */
package ejemplopolimorfismopersona;

import java.util.Map;
import java.util.List;

/**
 *
 * Interfaz Imprimible
 */
public interface Imprimible {
	String devolverContenidoString ();
	List devolverContenidoList (); 
	Map devolverContenidoMap (); 

}
