/*
 * Clase Alumno.
 */
package ejemplopolimorfismopersona;
import java.util.*;
import java.text.*;
import java.time.LocalDate;

/**
 *
 * Clase Alumno
 */
public class Alumno extends Persona  {
    protected String grupo;
    protected double notaMedia; 


    // Constructores
    // -------------
    /**
     * Constructor de la clase Alumno   
     * @param nombre            Nombre del alumno
     * @param apellidos         Apellidos del alumno
     * @param fechaNacim        Fecha de nacimiento del alumno
     * @param grupo             Grupo al que pertenece el alumno
     * @param notaMedia         Nota media del alumno
     */    
    public Alumno (String nombre, String apellidos, LocalDate fechaNacim, String grupo, double notaMedia) {
        super (nombre, apellidos, fechaNacim);
        this.grupo= grupo;
        this.notaMedia= notaMedia;            
    }
        
    /**
     * Constructor de la clase Alumno   
     * Valores por omisión para un alumno: Grupo "GEN" y nota media de 0.
     * @param nombre            Nombre del alumno
     * @param apellidos         Apellidos del alumno
     * @param fechaNacim        Fecha de nacimiento del alumno
     */   
    public Alumno (String nombre, String apellidos, LocalDate fechaNacim) {
        super (nombre, apellidos, fechaNacim);
        // Valores por omisión para un alumno: Grupo "GEN" y nota media de 0.
        this.grupo= "GEN";
        this.notaMedia= 0;                        
    }
        
    /** 
     * Getter del grupo
     * @return Grupo al que pertenece el alumno
     */
    public String getGrupo (){
        return grupo;
    }

    /**
     * Getter de la nota media
     * @return Nota Nota media del alumno
     */
    public double getNotaMedia (){
        return notaMedia;
    }

    /**
     * Setter del grupo
     * @param grupo Grupo al que pertenece el alumno
     */
    public void setGrupo (String grupo){
        this.grupo= grupo;
    }

    /** 
     * Setter de la nota media
     * @param notaMedia Nota media del alumno
     */
    public void setNotaMedia (double notaMedia){
        this.notaMedia= notaMedia;
    }

    // Redefinición de los métodos de la interfaz Imprimible
    // -------------------------------------------------------

    /**
     * Genera un Map con el contenido del objeto
     * @return Atributos del objeto en forma de Map
     */    
    @Override
    public Map devolverContenidoMap () {
        // Llamada al método de la superclase
        Map contenido= super.devolverContenidoMap();
        // Añadimos los atributos específicos
        contenido.put ("grupo", this.grupo);
        contenido.put ("notaMedia", this.notaMedia);
        // Devolvemos la Hashtable rellena                       
        return contenido;
    }

    /**
     * Genera una List con el contenido del objeto
     * @return Atributos del objeto en forma de List
     */    
    @Override
    public List devolverContenidoList () {
        // Llamada al método de la superclase
        List contenido= super.devolverContenidoList ();            
        // Añadimos los atributos específicos
        contenido.add(this.grupo);
        contenido.add (this.notaMedia);
        // Devolvemos el ArrayList relleno
        return contenido;
    }

    /**
     * Genera un String con el contenido del objeto
     * @return Atributos del objeto en forma de String
     */
    @Override
    public String devolverContenidoString () {
        // Aprovechamos el método estático para transformar una Hashtable en String
        String contenido= Persona.MapToString(this.devolverContenidoMap());
        // Devolvemos el String creado.
        return contenido;
    }

        
}

