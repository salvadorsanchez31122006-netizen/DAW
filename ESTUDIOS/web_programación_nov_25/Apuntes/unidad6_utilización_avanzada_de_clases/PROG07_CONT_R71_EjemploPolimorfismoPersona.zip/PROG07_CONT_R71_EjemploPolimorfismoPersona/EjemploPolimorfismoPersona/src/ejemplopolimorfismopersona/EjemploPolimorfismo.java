
/*
 * Ejemplo de utilización del polimorfismo y la ligadura dinámica.
 */
package ejemplopolimorfismopersona;

import java.time.LocalDate;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.time.DateTimeException;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * Ejemplo de utilización del polimorfismo y la ligadura dinámica.
 */
public class EjemploPolimorfismo {

    /**
     * Clase principal
     */
    public static void main(String[] args) {
        String stringContenidoUsuario;
        
        String nombre= null, apellidos= null, tipo= null;
        Persona usuario= null;
        LocalDate fecha= null;
        Scanner teclado= new Scanner (System.in);
        
        
        // PRESENTACIÓN
        // ------------
        System.out.printf ("PRUEBA DE USO DEl POLIMORFISMO Y LA LIGADURA DINÁMICA. \n");
        System.out.printf ("------------------------------------------------------\n\n");
        
        // ENTRADA DE DATOS
        // ----------------
        // Nombre
        System.out.print("Nombre del usuario: ");    
        nombre= teclado.nextLine();

        // Apellidos
        System.out.print("Apellidos del usuario: ");    
        apellidos= teclado.nextLine();

        // Fecha de nacimiento
        boolean fechaValida= false;
        do {
            int dia, mes, anio;
            
            System.out.print("Fecha de nacimiento del usuario: ");          
            try {
                System.out.print ("Día: ");
                dia= teclado.nextInt();
                System.out.print ("Mes: ");
                mes= teclado.nextInt();
                System.out.print ("Año: ");
                anio= teclado.nextInt();
                fecha= LocalDate.of (anio, mes, dia);
                fechaValida= true;
            }
            catch (InputMismatchException e) {
                System.err.println ("Dato incorrecto.");
                if (teclado.hasNext()) teclado.nextLine();
            }
            catch (DateTimeException e) {
                System.err.println ("Fecha inválida");
                System.err.println(e.getMessage());
            }        
        } while (!fechaValida);
        
        // ¿Alumno o Profesor?
        do {
            System.out.println("¿Es alumno(A) o profesor(P)?");          
            try {
                tipo= teclado.nextLine();
            }
            catch (Exception e) {
                System.err.println(e.getMessage());               
            }        
            if (tipo.equals("P") || tipo.equals("p")) tipo="profesor";
            else if (tipo.equals("A") || tipo.equals("a")) tipo="alumno";
            else tipo="X";

        } while (tipo.equals("X"));
        
        // Creación del objeto usuario (desconocido en tiempo de compilación)
        // Sabemos que será subclase de Persona, pero no sabemos si será Alumno o Profesor
        // (dependerá de la ejecución)
        if (tipo.equals("profesor")) {
            usuario= new Profesor (nombre, apellidos, fecha);
        }     
        else if (tipo.equals("alumno")) {
            usuario=  new Alumno (nombre, apellidos, fecha);            
        } else {
            // Esta situación no puede darse. Ha de ser profesor o alumno.
        }
      
        // Obtención del contenido del objeto usuario a través del método devolverContenidoString.
        // El método que se va a ajecutar aún no se sabe cuál es (ligadura dinámica), pues 
        // este objeto usuario no sabemos si será Alumno o Profesor. Tan solo sabemos que será de la
        // superclase Persona. En tiempo de ejecución se sabrá de qué tipo de subclase se trata y será
        // también en ese momento cuando el entorno de ejecución pueda resolver qué método se ejecuta
        // (el de método devolverContenidoString de la clase Alumno o el de la clase Profesor)
        
        stringContenidoUsuario= usuario.devolverContenidoString();
        
        // Impresión en pantalla del contenido del objeto usuario a través de la estructura obtenida
        System.out.printf ("Contenido del objeto usuario: %s\n", stringContenidoUsuario);      
       
    }
    
}
