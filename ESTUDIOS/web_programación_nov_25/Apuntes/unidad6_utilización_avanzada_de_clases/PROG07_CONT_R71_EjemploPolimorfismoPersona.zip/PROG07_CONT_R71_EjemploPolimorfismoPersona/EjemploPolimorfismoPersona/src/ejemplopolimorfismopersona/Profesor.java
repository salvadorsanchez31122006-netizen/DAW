/*
 * Clase Profesor
 */
package ejemplopolimorfismopersona;

/**

 */
import java.util.*;
import java.text.*;
import java.time.LocalDate;

/**
 *
 * Clase Profesor
 */
public class Profesor extends Persona {
	String especialidad;
	double salario; 
        
        // Constructores
        // -------------

    /**
     * Constructor de la clase Persona
     * @param nombre            Nombre del profesor
     * @param apellidos         Apellidos del profesor
     * @param fechaNacim        Fecha de nacimiento del profesor
     * @param especialidad      Especialidad del profesor
     * @param salario           Salario del profesor
     */
    public Profesor (String nombre, String apellidos, LocalDate fechaNacim, String especialidad, double salario) {
        super (nombre, apellidos, fechaNacim);
        this.especialidad= especialidad;
        this.salario= salario;            
    }
        
    /**
     * Constructor de la clase Alumno   
     * Valores por omisión para un alumno: Grupo "GEN" y nota media de 0.
     * @param nombre            Nombre del alumno
     * @param apellidos         Apellidos del alumno
     * @param fechaNacim        Fecha de nacimiento del alumno
     */   
    public Profesor (String nombre, String apellidos, LocalDate fechaNacim) {
        super (nombre, apellidos, fechaNacim);
        // Valores por omisión para un profesor: especialidad "GEN" y sueldo de 1500 euros.
        this.especialidad= "GEN";
        this.salario= 1500.0;                        
    }

    // Getters y Setters
    // -----------------

    /** 
     * Getter de la especialidad del profesor
     * @return Especialidad del profesor
     */
    public String getEspecialidad (){
        return especialidad;
    }

    /**
     * Getter del salario del profesor
     * @return Salario del profesor
     */
    public double getSalario (){
        return salario;
    }

    /**
     * Setter del salario del profesor
     * @param salario Salario del profesor
     */
    public void setSalario (double salario){
        this.salario= salario;
    }

    /**
     * Setter de la especialidad del profesor
     * @param especialidad Especialidad del profesor
     */
    public void setESpecialidad (String especialidad){
        this.especialidad= especialidad;
    }


    // Redefinición de los métodos de la interfaz Imprimible
    // -------------------------------------------------------

    /**
     * Genera un Map con el contenido del objeto
     * @return Atributos del objeto en forma de Map
     */    
    @Override
    public Map devolverContenidoMap () {
        // Llamada al método de la superclase
        Map contenido= super.devolverContenidoMap();
        // Añadimos los atributos específicos
        contenido.put ("salario", this.salario);
        contenido.put ("especialidad", this.especialidad);
        // Devolvemos la Hashtable rellena                       
        return contenido;
    }

    /**
     * Genera una List con el contenido del objeto
     * @return Atributos del objeto en forma de List
     */    
    @Override
    public List devolverContenidoList () {
        // Llamada al método de la superclase
        List contenido= super.devolverContenidoList ();            
        // Añadimos los atributos específicos
        contenido.add(this.salario);
        contenido.add (this.especialidad);
        // Devolvemos el ArrayList relleno
        return contenido;
    }

    /**
     * Genera un String con el contenido del objeto
     * @return Atributos del objeto en forma de String
     */
    @Override
    public String devolverContenidoString () {
        // Aprovechamos el método estático para transformar una Hashtable en String
        String contenido= Persona.MapToString(this.devolverContenidoMap());
        // Devolvemos el String creado.
        return contenido;
    }

}

