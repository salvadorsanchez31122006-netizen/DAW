/*
 * Clase Persona
 */
package ejemplopolimorfismopersona;

import java.time.LocalDate;
import java.util.ArrayList;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Clase abastracta Persona
 * Clase que representa a una persona.
 * No es instanciable.
 */
public abstract class Persona implements Imprimible {
    protected String nombre;
    protected String apellidos;
    protected LocalDate fechaNacim;

    // Constructores
    // -------------
    /**
     * Constructor de la clase Persona
     * @param nombre            Nombre de la persona
     * @param apellidos         Apellidos de la persona
     * @param fechaNacimiento   Fecha de nacimiento de la persona
     */
    public Persona (String nombre, String apellidos, LocalDate fechaNacimiento) {           
        this.nombre= nombre;
        this.apellidos= apellidos;
        this.fechaNacim= fechaNacimiento;
    }
    
    
    // Getters y Setters
    // -----------------

    /**
     * Getter del atributo nombre
     * @return Nombre de la persona
     */
    protected String getNombre (){
        return nombre;
    }

    /**
     * Getter del atributo apellidos
     * @return Apellidos de la persona
     */
    protected String getApellidos (){
        return apellidos;
    }

    /**
     * Getter de la fecha de nacimiento
     * @return Fecha de nacimiento de la persona
     */
    protected LocalDate getFechaNacim (){
        return this.fechaNacim;
    }

    /**
     * Setter del nombre
     * @param nombre Nombre de la persona
     */
    protected void setNombre (String nombre){
        this.nombre= nombre;
    }

    /**
     * Setter de los apellidos
     * @param apellidos Apellidos de la persona
     */
    protected void setApellidos (String apellidos){
        this.apellidos= apellidos;
    }

    /**
     * ¨Setter de la fecha de nacimiento
     * @param fechaNacim Fecha de nacimiento de la persona
     */
    protected void setFechaNacim (LocalDate fechaNacim){
        this.fechaNacim= fechaNacim;
    }
   
                
    // Implementación de los métodos de la interfaz Imprimible
    // -------------------------------------------------------
        
    // Método devolverContenidoMap 
    /**
     * Genera un Map con el contenido del objeto
     * @return Atributos del objeto en forma de Map
     */    
    public Map devolverContenidoMap () {
        // Creamos el Map que va a ser devuelto
        Map contenido= new HashMap ();

        // Añadimos los atributos específicos
        DateTimeFormatter formateadorFecha = DateTimeFormatter.ofPattern("dd/LL/yyyy");
        String fechaFormateada= formateadorFecha.format(fechaNacim);
        contenido.put ("apellidos", this.apellidos);
        contenido.put ("fechaNacim", fechaFormateada);

        // Devolvemos la Hashtable
        return contenido;
    }

    /**
     * Genera una List con el contenido del objeto
     * @return Atributos del objeto en forma de List
     */
    public List devolverContenidoList () {
        // Creamos la List que va a ser devuelta
        List contenido= new ArrayList ();
        
        // Añadimos los atributos específicos
        DateTimeFormatter formateadorFecha = DateTimeFormatter.ofPattern("dd/LL/yyyy");
        String fechaFormateada= formateadorFecha.format(fechaNacim);
        contenido.add(this.nombre);
        contenido.add (this.apellidos);
        contenido.add(fechaFormateada);

        return contenido;
    }


    /**
     * Genera un String con el contenido del objeto
     * @return Atributos del objeto en forma de String
     */
    public String devolverContenidoString () {
        String contenido= Persona.MapToString (this.devolverContenidoMap());
        return contenido;
    }        

    // Métodos estáticos (herramientas)
    // --------------------------------

    /**
     * Genera un String que representa el contenido de un Map
     * @param map Map que se desea "convertir" a String
     * @return String que representa el Map pasado como parámetro
     */
    protected static String MapToString (Map map) {
        String contenido;
        String clave;
        Set claves= map.keySet();
        Iterator it= claves.iterator();
        
        contenido= "{";
        if (it.hasNext()) {
            clave= it.next().toString();
            contenido= contenido + clave + "=" + map.get(clave).toString();
        }
        while (it.hasNext()) {
                clave= it.next().toString();
                contenido += ",";
                contenido= contenido.concat (clave) ;
                contenido= contenido.concat ("=" + map.get(clave));
        }
        contenido= contenido + "}";

        return contenido;
    }        
        
}

